import React from 'react';
import { View, Text, Button } from 'react-native';

export default function TaskDetailsScreen({ route, navigation }) {
  const { task } = route.params;

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold' }}>
        {task.title}
      </Text>
      <Text style={{ marginTop: 10 }}>{task.description}</Text>
      <Button title="Back" onPress={() => navigation.goBack()} />
    </View>
  );
}
