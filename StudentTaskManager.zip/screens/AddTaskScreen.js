import React from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

export default function AddTaskScreen() {
  return (
    <View style={styles.container}>
      <TextInput placeholder="Task Title" style={styles.input} />
      <TextInput placeholder="Description" style={styles.input} />
      <Button title="Add Task" onPress={() => alert('UI only')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  input: {
    borderWidth: 1,
    marginBottom: 15,
    padding: 10,
    borderRadius: 5,
  },
});
