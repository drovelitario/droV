import React from 'react';
import { View, FlatList, Button } from 'react-native';
import TaskItem from '../components/TaskItem';

export default function HomeScreen({ navigation }) {
  const tasks = [
    { id: '1', title: 'Study React', description: 'Review navigation' },
    { id: '2', title: 'Assignment', description: 'Finish UI task' },
  ];

  return (
    <View style={{ flex: 1, padding: 10 }}>
      <Button title="Add Task" onPress={() => navigation.navigate('AddTask')} />

      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskItem
            task={item}
            onPress={() => navigation.navigate('TaskDetails', { task: item })}
          />
        )}
      />
    </View>
  );
}
